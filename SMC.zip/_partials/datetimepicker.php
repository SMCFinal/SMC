<script src="../assets/bootstrap-datetimepicker.js"></script>

<!-- <script type="text/javascript" src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script> -->
