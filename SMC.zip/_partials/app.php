<script src="../assets/js/app.js"></script>
<script type="text/javascript" src="../assets/bootstrap-datepicker.min.js"></script>