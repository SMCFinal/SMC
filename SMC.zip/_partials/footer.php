<footer class="footer">
    ©2020 <b>SMC</b> <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Team DCS. 
    <b> 
        <span class="badge badge-primary" style="font-size: 14px;">V 2.8</span>
    </b></span>
</footer>